function overColor(){
    document.getElementById("border_name").classList.add("border_input");
}

function normalColor(){
    document.getElementById("border_name").classList.remove("border_input");
}

function overColor1(){
    document.getElementById("border_email").classList.add("border_input");
}

function normalColor1(){
    document.getElementById("border_email").classList.remove("border_input");
}

function overColor2(){
    document.getElementById("border_textarea").classList.add("border_textarea");
}

function normalColor2(){
    document.getElementById("border_textarea").classList.remove("border_textarea");
}


